import re

# 从相机日志中提取index、camera_timestamp和board_timestamp
# 对于index=0的一组log，记录了一包数据从loan到publish的过程，需要提取OnCameraData:749等关键字，并且完整的作为一组
# 42, 35501 T2878 OnCameraData:749 [info]  IPC log for index 0 point 0 before loan
# 43, 35501 T2878 OnCameraData:751 [info]  IPC log for index 0 point 1 after loan
# 44, 35501 T2878 OnCameraData:753 [info]  IPC log for index 0 point 2 before copy
# 45, 35502 T2878 OnCameraData:759 [info]  IPC log for index 0 point 3 after copy : p_camera_ptr 0xffffa85f9010 to sender 0xffff90e2a134, size = 522240, timestamp = 35464
# 46, 35503 T2878 OnCameraData:763 [info]  IPC log for index 0 point 4 after publish

# 对于index=1的一组log，记录了一包数据从loan到publish的过程，需要提取OnCameraData:768等关键字，并且完整的作为一组
# 49, 35595 T2886 OnCameraData:768 [info]  IPC log for index 1 point 0 before loan
# 50, 35595 T2886 OnCameraData:770 [info]  IPC log for index 1 point 1 after loan
# 51, 35595 T2886 OnCameraData:772 [info]  IPC log for index 1 point 2 before copy
# 52, 35595 T2886 OnCameraData:778 [info]  IPC log for index 1 point 3 after copy : p_camera_ptr 0xffffa8479010 to sender 0xffff88e2a134, size = 522240, timestamp = 35530
# 53, 35595 T2886 OnCameraData:782 [info]  IPC log for index 1 point 4 after publish
# 以上日志内容，需要读取并记录到新的文件中
# 新文件为camera_output.txt，格式为
# index 0, camera_timestamp 35464
# loan start 35501, loan end 35501, loan duration 0
# copy start 35501, copy end 35502, copy duration 1
# publish start 35502, publish end 35503, publish duration 1
# 如果数据不完整，打印警告
def extract_from_camera_log():
    input_file = "CAMERA_normal.log"
    output_file = "camera_output.txt"
    index_keywords = {
        0: [
            "OnCameraData:749", "OnCameraData:751",
            "OnCameraData:753", "OnCameraData:759", "OnCameraData:763"
        ],
        1: [
            "OnCameraData:768", "OnCameraData:770",
            "OnCameraData:772", "OnCameraData:778", "OnCameraData:782"
        ]
    }
    try:
        with open(input_file, "r", encoding="utf-8", errors='ignore') as infile:
            lines = infile.readlines()

        with open(output_file, "w", encoding="utf-8") as outfile:
            for index in [0, 1]:
                keywords = index_keywords[index]
                i = 0
                while i < len(lines):
                    # 寻找第一个关键字
                    if keywords[0] in lines[i] and f"index {index}" in lines[i]:
                        match_start_index = i
                        keyword_index = 1
                        matched_lines = [lines[i]]
                        j = i + 1
                        while j < len(lines) and keyword_index < len(keywords):
                            if keywords[keyword_index] in lines[j] and f"index {index}" in lines[j]:
                                matched_lines.append(lines[j])
                                keyword_index += 1
                            j += 1

                        # 检查是否匹配到完整的关键字序列
                        if keyword_index == len(keywords):
                            events = {}
                            camera_timestamp = None

                            for line in matched_lines:
                                board_timestamp_match = re.search(r"\d+, (\d+)", line)
                                if not board_timestamp_match:
                                    print(f"警告：行 {lines.index(line) + 1} 未找到 board_timestamp")
                                    continue
                                board_timestamp = int(board_timestamp_match.group(1))

                                if "timestamp =" in line:
                                    timestamp_match = re.search(r"timestamp = (\d+)", line)
                                    if timestamp_match:
                                        camera_timestamp = timestamp_match.group(1)
                                    else:
                                        print(f"警告：行 {lines.index(line) + 1} 包含 'timestamp =' 但未匹配到具体值")

                                if "before loan" in line:
                                    events.setdefault("loan", {})["start"] = board_timestamp
                                elif "after loan" in line:
                                    events.setdefault("loan", {})["end"] = board_timestamp
                                elif "before copy" in line:
                                    events.setdefault("copy", {})["start"] = board_timestamp
                                elif "after copy" in line:
                                    events.setdefault("copy", {})["end"] = board_timestamp
                                    # 复用 after copy 的时间作为 publish 的起始时间
                                    events.setdefault("publish", {})["start"] = board_timestamp
                                elif "after publish" in line:
                                    events.setdefault("publish", {})["end"] = board_timestamp

                            outfile.write(f"index {index}, camera_timestamp {camera_timestamp}\n")

                            for event, times in events.items():
                                if "start" in times and "end" in times:
                                    duration = times["end"] - times["start"]
                                    outfile.write(f"{event} start {times['start']}, {event} end {times['end']}, {event} duration {duration}\n")
                                else:
                                    # 添加 index 和 camera_timestamp 信息
                                    print(f"警告：index {index}, camera_timestamp {camera_timestamp} 的 {event} 数据不完整")
                            outfile.write("\n")
                            i = j
                        else:
                            i += 1
                    else:
                        i += 1

        print("提取完成，结果已保存到 camera_output.txt")
    except FileNotFoundError:
        print(f"未找到 {input_file} 文件，请检查文件路径。")
    except Exception as e:
        print(f"处理 {input_file} 文件时出错: {e}")

# 从EVENTTASK日志中提取index、camera_timestamp和board_timestamp
# 对于index=0的一组log，记录了一包数据从take到save的过程，需要提取ThreadCameraData:76等关键字，并且完整的作为一组接收过程
# 43143, 401038 T2733 ThreadCameraData:76 [info]  20250709 05:43:28.808020 IPC log for index 0 point 0 before take
# 43144, 401101 T2733 ThreadCameraData:78 [info]  20250709 05:43:28.808083 IPC log for index 0 point 1 after take
# 43145, 401101 T2733 ThreadCameraData:81 [info]  20250709 05:43:28.808083 whr Received Left Frame timestamp: 401064, Size: 522240, ptr: 0xffff9ec6cca0
# 43146, 401103 T2733 ThreadCameraData:92 [info]  20250709 05:43:28.808085 Saved origin: /mnt/data/rockrobo/devtest/output_debugIpcReciever_0_401064.yuv

# 对于index=1的一组log，记录了一包数据从take到save的过程，需要提取ThreadCameraData:97等关键字，并且完整的作为一组接收过程
# 43147, 401103 T2733 ThreadCameraData:97 [info]  20250709 05:43:28.808085 IPC log for index 1 point 0 before take
# 43148, 401103 T2733 ThreadCameraData:99 [info]  20250709 05:43:28.808085 IPC log for index 1 point 1 after take
# 43149, 401103 T2733 ThreadCameraData:102 [info]  20250709 05:43:28.808085 whr Received Right Frame timestamp: 398930, Size: 522240, ptr: 0xffff97285ca0
# 43150, 401104 T2733 ThreadCameraData:113 [info]  20250709 05:43:28.808087 Saved origin: /mnt/data/rockrobo/devtest/output_debugIpcReciever_1_398930.yuv

# 以上日志内容，需要读取并记录到新的文件中
# 新文件为event_output.txt，格式为
# index 0, camera_timestamp 401064
# take start 401038, take end 401101, take duration 63
# save start 401101, save end 401103, save duration 2
# 如果数据不完整，打印警告
def extract_from_eventtask_log():
    input_file = "EVENTTASK_normal.log"
    output_file = "event_output.txt"
    index_keywords = {
        0: [
            "ThreadCameraData:76", "ThreadCameraData:78",
            "ThreadCameraData:81", "ThreadCameraData:92"
        ],
        1: [
            "ThreadCameraData:97", "ThreadCameraData:99",
            "ThreadCameraData:102", "ThreadCameraData:113"
        ]
    }
    try:
        with open(input_file, "r", encoding="utf-8", errors='ignore') as infile:
            lines = infile.readlines()

        with open(output_file, "w", encoding="utf-8") as outfile:
            for index in [0, 1]:
                keywords = index_keywords[index]
                i = 0
                while i < len(lines):
                    # 寻找第一个关键字
                    if keywords[0] in lines[i]:
                        match_start_index = i
                        keyword_index = 1
                        matched_lines = [lines[i]]
                        j = i + 1
                        while j < len(lines) and keyword_index < len(keywords):
                            if keywords[keyword_index] in lines[j] :
                                matched_lines.append(lines[j])
                                keyword_index += 1
                            j += 1

                        # 检查是否匹配到完整的关键字序列
                        if keyword_index == len(keywords):
                            events = {}
                            camera_timestamp = None

                            for line in matched_lines:
                                board_timestamp_match = re.search(r"\d+, (\d+)", line)
                                if not board_timestamp_match:
                                    print(f"警告：行 {lines.index(line) + 1} 未找到 board_timestamp")
                                    continue
                                board_timestamp = int(board_timestamp_match.group(1))

                                if "output_debugIpcReciever_" in line:
                                    part = line.split("output_debugIpcReciever_")[1]
                                    idx, timestamp_part = part.split("_", 1)
                                    if int(idx) == index:
                                        camera_timestamp = timestamp_part.split(".")[0]
                                    else:
                                        print(f"警告：行 {lines.index(line) + 1} index 不匹配")

                                if "before take" in line:
                                    events.setdefault("take", {})["start"] = board_timestamp
                                elif "after take" in line:
                                    events.setdefault("take", {})["end"] = board_timestamp
                                elif "Saved origin" in line:
                                    if "save" not in events:
                                        events["save"] = {}
                                    if "start" not in events["save"]:
                                        events["save"]["start"] = board_timestamp
                                    events["save"]["end"] = board_timestamp

                            outfile.write(f"index {index}, camera_timestamp {camera_timestamp}\n")

                            for event, times in events.items():
                                if "start" in times and "end" in times:
                                    duration = times["end"] - times["start"]
                                    outfile.write(f"{event} start {times['start']}, {event} end {times['end']}, {event} duration {duration}\n")
                                else:
                                    print(f"警告：index {index}, camera_timestamp {camera_timestamp} 的 {event} 数据不完整")
                            outfile.write("\n")
                            i = j
                        else:
                            i += 1
                    else:
                        i += 1

        print("从 EVENTTASK_normal.log 提取完成，结果已保存到 event_output.txt")
    except FileNotFoundError:
        print(f"未找到 {input_file} 文件，请检查文件路径。")
    except Exception as e:
        print(f"处理 {input_file} 文件时出错: {e}")


# 对文件进行排序
def sort_file(input_file, output_file):
    try:
        # 读取输入文件的所有行
        with open(input_file, "r", encoding="utf-8") as infile:
            lines = infile.readlines()

        # 存储原始行数以作对比
        original_lines = lines.copy()

        # 分组，将每个 camera_timestamp 及其关联信息作为一组
        groups = []
        current_group = []
        for line in lines:
            if line.startswith("index "):
                if current_group:
                    groups.append(current_group)
                current_group = [line]
            else:
                current_group.append(line)
        if current_group:
            groups.append(current_group)

        # 定义提取 camera_timestamp 的函数
        def get_camera_timestamp(group):
            for line in group:
                if "camera_timestamp" in line:
                    try:
                        parts = line.split("camera_timestamp ")
                        if len(parts) > 1:
                            timestamp_str = parts[1].strip().split()[0]
                            return int(timestamp_str)
                    except (ValueError, IndexError) as e:
                        print(f"提取 camera_timestamp 出错，行内容: {line.strip()}，错误信息: {e}")
            return 0

        # 按 camera_timestamp 对组进行排序
        groups.sort(key=get_camera_timestamp)

        # 重新组合排序后的组
        sorted_lines = []
        for group in groups:
            sorted_lines.extend(group)

        # 写入排序后的内容到输出文件
        with open(output_file, "w", encoding="utf-8") as outfile:
            outfile.writelines(sorted_lines)

        # 验证排序前后行数是否一致
        if len(original_lines) != len(sorted_lines):
            print(f"警告：排序后行数改变，原始行数: {len(original_lines)}，当前行数: {len(sorted_lines)}")

        # 验证所有原始行是否都存在于排序后的结果中
        original_lines_set = set(original_lines)
        sorted_lines_set = set(sorted_lines)
        if original_lines_set != sorted_lines_set:
            missing_lines = original_lines_set - sorted_lines_set
            extra_lines = sorted_lines_set - original_lines_set
            if missing_lines:
                print(f"警告：以下原始行不在排序后的结果中: {missing_lines}")
            if extra_lines:
                print(f"警告：排序后的结果包含额外的行: {extra_lines}")

        print(f"{input_file} 排序完成，结果已保存到 {output_file}")
    except FileNotFoundError:
        print(f"未找到 {input_file} 文件，请检查文件路径。")
    except Exception as e:
        print(f"处理 {input_file} 文件时出错: {e}")

# 计算各种 duration，同时统计丢失的消息，将结果保存到统计文件
def calculate_durations(camera_input_file, event_input_file, stats_output_file):
    try:
        # 读取 camera 日志文件
        with open(camera_input_file, "r", encoding="utf-8") as infile:
            camera_lines = infile.readlines()

        # 读取 event 日志文件
        with open(event_input_file, "r", encoding="utf-8") as infile:
            event_lines = infile.readlines()

        # 初始化持续时间统计字典，用于记录每包的统计情况
        durations_per_packet = {}
        # 初始化持续时间统计字典，用于记录总和
        durations_sum = {
            "loan": 0,
            "copy": 0,
            "publish": 0,
            "publish_to_take": 0,
            "take": 0,
            "save": 0,
            "total": 0
        }
        # 初始化计数字典，用于记录每个阶段的有效数据数量
        durations_count = {
            "loan": 0,
            "copy": 0,
            "publish": 0,
            "publish_to_take": 0,
            "take": 0,
            "save": 0
        }

        # 提取 camera_timestamp 和 index 到字典
        camera_timestamps = {}
        event_timestamps = {}

        # 提取 camera 日志中的 index、camera_timestamp 和 publish 信息
        for i in range(len(camera_lines)):
            if "camera_timestamp" in camera_lines[i]:
                parts = camera_lines[i].split(', ')
                index = int(parts[0].split(' ')[1])
                camera_timestamp = int(parts[1].split(' ')[1])
                key = (index, camera_timestamp)
                camera_timestamps[key] = {"publish": False}
                for j in range(i, len(camera_lines)):
                    if "publish end" in camera_lines[j]:
                        camera_timestamps[key]["publish"] = True
                        break

        # 提取 event 日志中的 index、camera_timestamp 和 take 信息
        for i in range(len(event_lines)):
            if "camera_timestamp" in event_lines[i]:
                parts = event_lines[i].split(', ')
                index = int(parts[0].split(' ')[1])
                camera_timestamp = int(parts[1].split(' ')[1])
                key = (index, camera_timestamp)
                event_timestamps[key] = {"take": False}
                for j in range(i, len(event_lines)):
                    if "take start" in event_lines[j]:
                        event_timestamps[key]["take"] = True
                        break

        # 统计丢失的消息
        lost_messages = []
        for key in camera_timestamps:
            if camera_timestamps[key]["publish"] and (key not in event_timestamps or not event_timestamps[key]["take"]):
                lost_messages.append(key)

        publish_end_dict = {}
        take_start_dict = {}

        # 提取每个 index 和 camera_timestamp 对应的 publish end 时间
        for line in camera_lines:
            if "camera_timestamp" in line:
                parts = line.split(', ')
                index = int(parts[0].split(' ')[1])
                camera_timestamp = int(parts[1].split(' ')[1])
                key = (index, camera_timestamp)
            if "publish end" in line:
                publish_end = int(line.split("publish end ")[1].split(",")[0])
                publish_end_dict[key] = publish_end

        # 提取每个 index 和 camera_timestamp 对应的 take start 时间
        for line in event_lines:
            if "camera_timestamp" in line:
                parts = line.split(', ')
                index = int(parts[0].split(' ')[1])
                camera_timestamp = int(parts[1].split(' ')[1])
                key = (index, camera_timestamp)
            if "take start" in line:
                take_start = int(line.split("take start ")[1].split(",")[0])
                take_start_dict[key] = take_start

        # 计算 publish_to_take 持续时间并记录每包情况
        for key in publish_end_dict:
            if key in take_start_dict:
                duration = take_start_dict[key] - publish_end_dict[key]
                if key not in durations_per_packet:
                    durations_per_packet[key] = {}
                durations_per_packet[key]["publish_to_take"] = duration
                durations_sum["publish_to_take"] += duration
                durations_count["publish_to_take"] += 1

        # 提取各阶段 duration 并记录每包情况
        for line in camera_lines + event_lines:
            if "camera_timestamp" in line:
                parts = line.split(', ')
                index = int(parts[0].split(' ')[1])
                camera_timestamp = int(parts[1].split(' ')[1])
                key = (index, camera_timestamp)
                if key not in durations_per_packet:
                    durations_per_packet[key] = {}
            for event in ["loan", "copy", "publish", "take", "save"]:
                if f"{event} duration" in line:
                    duration = int(line.split(f"{event} duration ")[1].strip())
                    durations_per_packet[key][event] = duration
                    durations_sum[event] += duration
                    durations_count[event] += 1

        # 计算平均值
        durations_avg = {}
        for event in durations_sum:
            if event != "total" and durations_count[event] > 0:
                durations_avg[event] = durations_sum[event] / durations_count[event]
            else:
                durations_avg[event] = 0

        durations_sum["total"] = sum([durations_sum[event] for event in durations_sum if event != "total"])
        durations_avg["total"] = sum([durations_avg[event] for event in durations_avg if event != "total"])

        # 将统计结果写入统计文件
        with open(stats_output_file, "w", encoding="utf-8") as stats_outfile:
            # 输出丢失的消息
            stats_outfile.write("丢失的消息的 (index, camera_timestamp) 如下：\n")
            stats_outfile.write(str(lost_messages) + "\n\n")

            # 输出每包的统计情况
            stats_outfile.write("每包的统计情况如下：\n")
            for key in sorted(durations_per_packet.keys()):
                index, camera_timestamp = key
                stats_outfile.write(f"index: {index}, camera_timestamp: {camera_timestamp}\n")
                for event in ["loan", "copy", "publish", "publish_to_take", "take", "save"]:
                    stats_outfile.write(f"{event} duration: {durations_per_packet[key].get(event, 'N/A')}\n")
                stats_outfile.write("\n")

            # 输出平均值
            stats_outfile.write("各阶段持续时间平均值如下：\n")
            for event, avg in durations_avg.items():
                stats_outfile.write(f"{event} duration avg: {avg:.2f}\n")

        print(f"统计完成，结果已保存到 {stats_output_file}")

    except FileNotFoundError:
        print(f"未找到文件，请检查文件路径。")
    except Exception as e:
        print(f"处理文件时出错: {e}")


if __name__ == "__main__":
    extract_from_camera_log()
    extract_from_eventtask_log()
    sort_file("camera_output.txt", "sorted_camera_output.txt")
    sort_file("event_output.txt", "sorted_event_output.txt")
    calculate_durations("sorted_camera_output.txt", "sorted_event_output.txt", "stats_output.txt")
    input("按回车键退出...")